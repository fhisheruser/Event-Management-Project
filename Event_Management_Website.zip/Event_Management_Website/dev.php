

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"
/>
    <link rel="stylesheet" href="style.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
      integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,400;0,500;1,300&family=Lora:ital,wght@0,500;0,600;1,400;1,600&family=Roboto:wght@500&family=Urbanist:wght@200;300;400;500;600&family=Varela+Round&display=swap"
      rel="stylesheet"
    />
    <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
    crossorigin="anonymous"
    />
    <style>
      .head{
    align-items: center;
    margin-left: 500px;
    font-size: 50px;
    color: black;
}
.team{
   
    align-items: center;
   margin-bottom: 40px;
    font-size: 50px;
    margin-left: 600px;

}
h3{
  font-size: 40px;
}
    </style>
  </head>
  <body>

    <b><div class="team">OUR DEVELOPERS TEAM</div></b>
    <!-- <div class="head"><b>RUDRAKSHA WELFARE FOUNDATION</b></div> -->
 
  <!-- <div class="contents">
    <img src="rudraksha.png" class="image2">
      <p>
          The website was designed and developed as per the customized requirements of the concerned Management of "Occult Science Foundation". The students have done an internship with RUDRAKSHA WELFARE FOUNDATION, under the guidance and supervision of Mr. Atul Dev Arora, Managing Director. The company is A Section 8 Company under Ministry of Corporate Affairs, GOI..
      </p>
  </div> -->
      <!-- <div class="management">
        <img src="./Images/manage.jpg" alt="" />
      </div> -->
      <div class="org">
        
        <img src="rudraksha.png">
        <div class="org1">
       <h3><b><u>RUDRAKSHA WELFARE FOUNDATION</u></b></h3>
 
        <!-- <h4>Director</h4> -->
        <p>
          The website was designed and developed as per the customized requirements of the concerned Management 
          of " ". The students have done an internship with RUDRAKSHA WELFARE FOUNDATION, 
          under the guidance and supervision of Mr. Atul Dev Arora Founder Director, RUDRAKSHA WELFARE FOUNDATION, which is a Section 8 
          unit under the Ministry of Corporate Affairs, GOI.
      </p>        </div>
      </div>
      <br>
      <br>

      <div class="org">
        <img src="leena.jpeg">
        <div class="org1">
        <h3><u>Ms. Leena Rajan Katkar</u></h3>
        <p>Leena Rajan Katkar, currently studing in Btech Information Technology at Saraswati College of Engineering. She
           has been part of Rudraksha Welfare Foundation as a Full-stack developer. She has a great zeal to learn
            new technologies and quiet capable of developing and designing website technologies in HTML,CSS, 
            JavaScript PHP MySQL. To find more about her you can get connected with her via @leenakatkar60@gmail.com</p>
        </div>
      </div>
      <br>
      <br>
     
       <div class="org">
        <img src="mohit.jpg">
        <div class="org1">
        <h3><u>Mr. Mohit Narendra Bhoir</u></h3>
        
        <p>Mohit Narendra Bhoir, Currently pursuing bachelor's degree ( Final Year ) in Artificial Intelligence at Smt.
           Indira Gandhi College of Engineering. He has been part of RUDRAKSHA WELFARE FOUNDATION as a graphics designer. 
           He has experience for more than 3 Years in adobe suite softwares such as Adobe Photoshop , After effects,
             Premiere pro , etc. To find more about him you can get connected with him via @bhoirmohit1010@gmail.com  </p>
                </div>
      </div>
      <br>
      <br>
      <div class="org">
        <img src="ketki.jpeg" style="width: 320px; height: 320px;">
        <div class="org1">
        <h3><u>Ms. Ketki Pratap Mane</u></h3>
       
        <p>Ketki Pratap Mane, is a budding software developer professional who has a great zeal to learn new
           technologies and is quite capable of developing and designing websites in the technologies like: HTML 
           CSS JavaScript PHP MySQL. She is enjoying her learning phase in the BTech Information Technology 
           at Saraswati College of Engineering. She can be reached via ketkimane1806@gmail.com</p>      </div>
      </div>
    </div>
      <br>
      <br>  
      <?php require 'utils/footer.php'; ?><!--footer content. file found in utils folder-->


      <script src="https://code.jquery.com/jquery-3.6.3.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
      <script
      src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
      integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
      integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
      integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://kit.fontawesome.com/deb4d1b812.js"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
      integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
      integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
      integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
      crossorigin="anonymous"
    ></script>
    
  </body>
  </html>